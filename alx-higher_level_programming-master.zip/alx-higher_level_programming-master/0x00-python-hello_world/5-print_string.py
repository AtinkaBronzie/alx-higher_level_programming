#!/usr/bin/python3
str = "Holberton School"
print(f"{str * 3}")
print(str[:9])
