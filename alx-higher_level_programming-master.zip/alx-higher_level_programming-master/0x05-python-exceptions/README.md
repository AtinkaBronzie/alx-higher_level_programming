Projects on Python Doubly Linked Lists- 0x05-python-exceptions
