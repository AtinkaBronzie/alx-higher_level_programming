#!/usr/bin/python3
exec("import os; os.write(1, b'#pythoniscool\\n')")
