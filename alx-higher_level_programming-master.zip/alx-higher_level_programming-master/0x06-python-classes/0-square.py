#!/usr/bin/python3
"""defines class square """


class Square:
    """ empty square """
    pass
