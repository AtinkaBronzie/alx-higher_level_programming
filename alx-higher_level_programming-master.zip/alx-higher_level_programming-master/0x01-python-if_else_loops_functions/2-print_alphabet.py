#!/usr/bin/python3
for i in range(97, 123):
    print('{}'.format(chr(i)), end='')
