#!/usr/bin/python3
for num in range(0, 99):
    print('{0} = {1}'.format(num, hex(num)))
